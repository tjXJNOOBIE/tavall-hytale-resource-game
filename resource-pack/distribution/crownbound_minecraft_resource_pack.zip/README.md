# Crownbound Minecraft Java Resource Pack

First-pass Minecraft Java resource-pack scaffold for the Crownbound / Kingdom UI button atlases.

## Included

- `pack.mcmeta`
- `pack.png`
- Button atlas textures under `assets/crownbound/textures/gui/buttons/`
- Button family manifests under `assets/crownbound/ui/buttons/`
- Basic localization keys under `assets/crownbound/lang/en_us.json`
- Placeholder font provider under `assets/crownbound/font/ui_buttons.json`

## Important

Minecraft Java resource packs provide visual assets, fonts, sounds, models, and language files.
They do not provide a complete custom UI framework by themselves.

A server plugin should handle:

- Opening menus
- Slot click routing
- Player-specific data
- Button state resolution
- Dynamic labels
- Currency/prices/counts
- Menu refreshes

## Button atlas families

- `button_primary`
- `button_secondary`
- `button_danger`
- `button_success`
- `button_tab`
- `button_icon`

## Next technical step

The atlas sheets need deterministic slicing.

Recommended pipeline:

1. Slice each atlas into stable regions.
2. Fill exact `x`, `y`, `w`, `h` coordinates in each manifest.
3. Generate inventory GUI backgrounds or custom bitmap font glyphs from the regions.
4. Route clicks through your plugin's inventory UI manager.
5. Keep dynamic text out of PNGs.

## Version target

This pack uses:

```json
{
  "pack_format": 64,
  "supported_formats": {
    "min_inclusive": 34,
    "max_inclusive": 64
  }
}
```

That makes the scaffold intended for modern Java 1.21.x resource-pack testing.
